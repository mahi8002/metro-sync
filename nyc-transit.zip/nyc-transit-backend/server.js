<!DOCTYPE html>
<html lang="en" class="dark">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>NYC Transit Hub - Integrated System Dashboard</title>
  
  <!-- Tailwind CSS CDN -->
  <script src="https://cdn.tailwindcss.com"></script>
  
  <!-- FontAwesome Icons CDN -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
  
  <!-- Leaflet CSS & JS for Interactive Map -->
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
  <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

  <!-- Inter Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" />

  <script>
    tailwind.config = {
      darkMode: 'class',
      theme: {
        extend: {
          fontFamily: { sans: ['Inter', 'sans-serif'] },
          colors: {
            mta: {
              ACE: '#0039A6', BDFM: '#FF6319', G: '#6CBE45', JZ: '#996633',
              NQRW: '#FCCC0A', L: '#A7A9AC', 123: '#EE352E', 456: '#00933C',
              7: '#B933AD', SIR: '#00A8B5'
            }
          }
        }
      }
    }
  </script>

  <style>
    ::-webkit-scrollbar { width: 6px; height: 6px; }
    ::-webkit-scrollbar-track { background: #0f172a; }
    ::-webkit-scrollbar-thumb { background: #334155; border-radius: 3px; }
    ::-webkit-scrollbar-thumb:hover { background: #475569; }
    .pulse-dot { animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite; }
    @keyframes pulse { 0%, 100% { opacity: 1; transform: scale(1); } 50% { opacity: 0.5; transform: scale(0.95); } }
    .no-scrollbar::-webkit-scrollbar { display: none; }
    .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
    
    #mapContainer { 
      height: 600px; 
      width: 100%; 
      border-radius: 0.75rem; 
      z-index: 10; 
    }
    
    /* Terminal End-Cap MTA Route Badges */
    .mta-map-bullet {
      width: 24px;
      height: 24px;
      border-radius: 9999px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 800;
      font-size: 11px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.7);
      border: 1.5px solid #ffffff;
    }
  </style>
</head>

<body class="bg-slate-950 text-slate-100 font-sans min-h-screen flex flex-col antialiased">

  <!-- HEADER & NAVIGATION BAR -->
  <header class="border-b border-slate-800 bg-slate-900/90 backdrop-blur sticky top-0 z-30 px-4 lg:px-8 py-3.5 flex flex-wrap items-center justify-between gap-4">
    <div class="flex items-center gap-3">
      <div class="w-10 h-10 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 shrink-0">
        <i class="fa-solid fa-subway text-xl"></i>
      </div>
      <div>
        <h1 class="font-bold text-lg text-white leading-tight flex items-center gap-2">
          NYC Transit Hub
          <span class="text-xs font-normal text-indigo-300 px-2.5 py-0.5 rounded-full bg-indigo-950 border border-indigo-800/60">System Engine</span>
        </h1>
        <p class="text-xs text-slate-400">Endpoint: <code class="text-indigo-400 font-mono bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800">http://localhost:5000/api/v1/trains/live</code></p>
      </div>
    </div>

    <!-- MAIN TAB NAVIGATION -->
    <div class="flex items-center bg-slate-950 border border-slate-800 p-1 rounded-xl gap-1">
      <button onclick="switchTab('arrivals')" id="tab-arrivals" class="px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-2 bg-indigo-600 text-white">
        <i class="fa-solid fa-list-check"></i>
        <span>Arrivals</span>
      </button>
      <button onclick="switchTab('map')" id="tab-map" class="px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-2 text-slate-400 hover:text-white hover:bg-slate-900">
        <i class="fa-solid fa-map-location-dot"></i>
        <span>Live Map</span>
      </button>
      <button onclick="switchTab('accessibility')" id="tab-accessibility" class="px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-2 text-slate-400 hover:text-white hover:bg-slate-900">
        <i class="fa-solid fa-wheelchair"></i>
        <span>Accessibility</span>
      </button>
    </div>

    <!-- BACKEND CONTROLS & LATENCY -->
    <div class="flex items-center gap-3 flex-wrap">
      <div id="connectionStatusBadge" class="flex items-center gap-2 px-3 py-1.5 rounded-full border text-xs font-medium bg-slate-800/80 border-slate-700 text-slate-400">
        <span id="statusDot" class="w-2.5 h-2.5 rounded-full bg-slate-500 inline-block pulse-dot"></span>
        <span id="statusText">Connecting...</span>
      </div>

      <div id="latencyBadge" class="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-slate-800 bg-slate-950 text-xs text-slate-400 font-mono">
        <i class="fa-solid fa-gauge-high text-slate-500"></i>
        <span id="latencyText">-- ms</span>
      </div>

      <div class="flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-lg p-1">
        <select id="autoRefreshInterval" class="bg-slate-950 text-xs text-slate-300 rounded px-2 py-1 border border-slate-800 focus:outline-none">
          <option value="0">Auto Off</option>
          <option value="15000" selected>Every 15s</option>
          <option value="30000">Every 30s</option>
        </select>
        <button onclick="fetchLiveData()" class="px-3 py-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded text-xs font-medium transition flex items-center gap-1.5">
          <i id="fetchSpinner" class="fa-solid fa-rotate hidden animate-spin"></i>
          <span>Refresh</span>
        </button>
      </div>

      <button onclick="toggleJsonModal(true)" class="p-2 text-slate-400 hover:text-white bg-slate-900 border border-slate-800 rounded-lg text-xs">
        <i class="fa-solid fa-code"></i>
      </button>
    </div>
  </header>

  <main class="flex-1 p-4 lg:p-8 max-w-7xl w-full mx-auto space-y-6">

    <!-- METRICS STATS BAR -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-4 flex items-center justify-between">
        <div>
          <p class="text-xs font-medium text-slate-400">Active Trains Parsed</p>
          <h2 id="metricTrainCount" class="text-2xl font-bold text-white mt-1">--</h2>
        </div>
        <div class="w-10 h-10 rounded-lg bg-blue-500/10 text-blue-400 border border-blue-500/20 flex items-center justify-center text-lg">
          <i class="fa-solid fa-train-subway"></i>
        </div>
      </div>

      <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-4 flex items-center justify-between">
        <div>
          <p class="text-xs font-medium text-slate-400">Backend Cache Status</p>
          <div id="metricCacheStatus" class="mt-1"><span class="text-lg font-bold text-slate-500">--</span></div>
        </div>
        <div class="w-10 h-10 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20 flex items-center justify-center text-lg">
          <i class="fa-solid fa-bolt"></i>
        </div>
      </div>

      <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-4 flex items-center justify-between">
        <div>
          <p class="text-xs font-medium text-slate-400">Cache Engine</p>
          <h2 id="metricCacheEngine" class="text-lg font-bold text-slate-300 mt-1 uppercase">--</h2>
        </div>
        <div class="w-10 h-10 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center justify-center text-lg">
          <i class="fa-solid fa-database"></i>
        </div>
      </div>

      <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-4 flex items-center justify-between">
        <div>
          <p class="text-xs font-medium text-slate-400">Last Fetch Time</p>
          <h2 id="metricLastFetch" class="text-sm font-semibold text-slate-300 mt-2">Never</h2>
        </div>
        <div class="w-10 h-10 rounded-lg bg-purple-500/10 text-purple-400 border border-purple-500/20 flex items-center justify-center text-lg">
          <i class="fa-regular fa-clock"></i>
        </div>
      </div>
    </div>

    <!-- VIEW 1: LIVE ARRIVALS BOARD -->
    <section id="view-arrivals" class="space-y-6">
      <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-4">
        <div class="space-y-2">
          <div class="flex items-center justify-between">
            <span class="text-xs font-bold text-slate-400 uppercase tracking-wider">Subway Line Filters (All 24 Routes):</span>
            <span id="filterCountBadge" class="text-[10px] text-slate-500 font-mono">Showing: All Lines</span>
          </div>
          <div class="flex items-center gap-1.5 overflow-x-auto pb-2 no-scrollbar">
            <button onclick="filterByRoute('ALL')" class="route-filter-btn active ring-2 ring-indigo-400 ring-offset-2 ring-offset-slate-950 px-3 py-1 rounded-full text-xs font-bold bg-indigo-600 text-white shrink-0">ALL</button>
            <button onclick="filterByRoute('A')" class="route-filter-btn px-2.5 py-1 rounded-full text-xs font-bold bg-blue-600 text-white shrink-0">A</button>
            <button onclick="filterByRoute('C')" class="route-filter-btn px-2.5 py-1 rounded-full text-xs font-bold bg-blue-600 text-white shrink-0">C</button>
            <button onclick="filterByRoute('E')" class="route-filter-btn px-2.5 py-1 rounded-full text-xs font-bold bg-blue-600 text-white shrink-0">E</button>
            <button onclick="filterByRoute('B')" class="route-filter-btn px-2.5 py-1 rounded-full text-xs font-bold bg-orange-500 text-white shrink-0">B</button>
            <button onclick="filterByRoute('D')" class="route-filter-btn px-2.5 py-1 rounded-full text-xs font-bold bg-orange-500 text-white shrink-0">D</button>
            <button onclick="filterByRoute('F')" class="route-filter-btn px-2.5 py-1 rounded-full text-xs font-bold bg-orange-500 text-white shrink-0">F</button>
            <button onclick="filterByRoute('M')" class="route-filter-btn px-2.5 py-1 rounded-full text-xs font-bold bg-orange-500 text-white shrink-0">M</button>
            <button onclick="filterByRoute('G')" class="route-filter-btn px-2.5 py-1 rounded-full text-xs font-bold bg-lime-500 text-black shrink-0">G</button>
            <button onclick="filterByRoute('J')" class="route-filter-btn px-2.5 py-1 rounded-full text-xs font-bold bg-amber-800 text-white shrink-0">J</button>
            <button onclick="filterByRoute('Z')" class="route-filter-btn px-2.5 py-1 rounded-full text-xs font-bold bg-amber-800 text-white shrink-0">Z</button>
            <button onclick="filterByRoute('N')" class="route-filter-btn px-2.5 py-1 rounded-full text-xs font-bold bg-amber-400 text-black shrink-0">N</button>
            <button onclick="filterByRoute('Q')" class="route-filter-btn px-2.5 py-1 rounded-full text-xs font-bold bg-amber-400 text-black shrink-0">Q</button>
            <button onclick="filterByRoute('R')" class="route-filter-btn px-2.5 py-1 rounded-full text-xs font-bold bg-amber-400 text-black shrink-0">R</button>
            <button onclick="filterByRoute('W')" class="route-filter-btn px-2.5 py-1 rounded-full text-xs font-bold bg-amber-400 text-black shrink-0">W</button>
            <button onclick="filterByRoute('L')" class="route-filter-btn px-2.5 py-1 rounded-full text-xs font-bold bg-slate-400 text-black shrink-0">L</button>
            <button onclick="filterByRoute('1')" class="route-filter-btn px-2.5 py-1 rounded-full text-xs font-bold bg-red-600 text-white shrink-0">1</button>
            <button onclick="filterByRoute('2')" class="route-filter-btn px-2.5 py-1 rounded-full text-xs font-bold bg-red-600 text-white shrink-0">2</button>
            <button onclick="filterByRoute('3')" class="route-filter-btn px-2.5 py-1 rounded-full text-xs font-bold bg-red-600 text-white shrink-0">3</button>
            <button onclick="filterByRoute('4')" class="route-filter-btn px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-600 text-white shrink-0">4</button>
            <button onclick="filterByRoute('5')" class="route-filter-btn px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-600 text-white shrink-0">5</button>
            <button onclick="filterByRoute('6')" class="route-filter-btn px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-600 text-white shrink-0">6</button>
            <button onclick="filterByRoute('7')" class="route-filter-btn px-2.5 py-1 rounded-full text-xs font-bold bg-purple-600 text-white shrink-0">7</button>
            <button onclick="filterByRoute('SI')" class="route-filter-btn px-2.5 py-1 rounded-full text-xs font-bold bg-cyan-700 text-white shrink-0">SIR</button>
          </div>
        </div>

        <div class="relative w-full">
          <i class="fa-solid fa-magnifying-glass absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 text-sm"></i>
          <input id="searchInput" oninput="handleSearch()" type="text" placeholder="Search by station name (e.g. Times Sq, Atlantic Av), stop ID, or trip ID..." 
                 class="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 text-xs text-slate-200 rounded-lg pl-10 pr-10 py-2.5 focus:outline-none" />
        </div>
      </div>

      <div id="trainsGrid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"></div>
    </section>

    <!-- VIEW 2: INTERACTIVE LEAFLET SYSTEM MAP -->
    <section id="view-map" class="hidden space-y-4">
      <div class="bg-slate-900 border border-slate-800 p-4 rounded-xl flex items-center justify-between">
        <div>
          <h3 class="font-bold text-sm text-white flex items-center gap-2">
            <i class="fa-solid fa-map text-indigo-400"></i> Interactive NYC Subway System Map
          </h3>
          <p class="text-xs text-slate-400">OpenStreetMap background, solid track polylines, and circular station nodes.</p>
        </div>
        <button onclick="recenterMap()" class="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-indigo-300 rounded text-xs font-medium border border-slate-700">
          Re-center NYC
        </button>
      </div>
      <div id="mapContainer"></div>
    </section>

    <!-- VIEW 3: ACCESSIBILITY & EQUIPMENT OUTAGES -->
    <section id="view-accessibility" class="hidden space-y-4">
      <div class="bg-slate-900 border border-slate-800 p-4 rounded-xl flex items-center justify-between">
        <div>
          <h3 class="font-bold text-sm text-white flex items-center gap-2">
            <i class="fa-solid fa-wheelchair text-indigo-400"></i> Elevator & Escalator Outage Tracker
          </h3>
          <p class="text-xs text-slate-400">Real-time equipment availability from MTA Equipment Outage REST API.</p>
        </div>
        <button onclick="fetchAccessibilityData()" class="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded text-xs font-medium">
          Fetch Outages
        </button>
      </div>
      <div id="outagesGrid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"></div>
    </section>

  </main>

  <!-- RAW JSON INSPECTOR MODAL -->
  <div id="jsonModal" class="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 hidden flex-col justify-center p-6">
    <div class="bg-slate-900 border border-slate-800 w-full max-w-4xl max-h-[85vh] rounded-2xl flex flex-col shadow-2xl mx-auto overflow-hidden">
      <div class="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
        <h3 class="font-bold text-slate-200 text-sm">Raw Express API Response Inspector</h3>
        <button onclick="toggleJsonModal(false)" class="text-slate-400 hover:text-white"><i class="fa-solid fa-xmark"></i></button>
      </div>
      <div class="p-4 flex-1 overflow-y-auto bg-slate-950 font-mono text-xs">
        <pre id="jsonViewer" class="text-emerald-400 whitespace-pre-wrap break-all"></pre>
      </div>
    </div>
  </div>

  <script>
    let rawApiResponse = null;
    let allTrains = [];
    let selectedRoute = 'ALL';
    let searchQuery = '';
    let autoRefreshTimer = null;
    let leafletMap = null;
    let mapMarkersGroup = null;
    let trackLinesGroup = null;

    const routeColorMap = {
      A: 'bg-blue-600 text-white', C: 'bg-blue-600 text-white', E: 'bg-blue-600 text-white',
      B: 'bg-orange-500 text-white', D: 'bg-orange-500 text-white', F: 'bg-orange-500 text-white', M: 'bg-orange-500 text-white',
      G: 'bg-lime-500 text-black', J: 'bg-amber-800 text-white', Z: 'bg-amber-800 text-white',
      N: 'bg-amber-400 text-black', Q: 'bg-amber-400 text-black', R: 'bg-amber-400 text-black', W: 'bg-amber-400 text-black',
      L: 'bg-slate-400 text-black', '1': 'bg-red-600 text-white', '2': 'bg-red-600 text-white', '3': 'bg-red-600 text-white',
      '4': 'bg-emerald-600 text-white', '5': 'bg-emerald-600 text-white', '6': 'bg-emerald-600 text-white',
      '7': 'bg-purple-600 text-white', SI: 'bg-cyan-700 text-white', SIR: 'bg-cyan-700 text-white', S: 'bg-slate-500 text-white'
    };

    const hexColorMap = {
      A: '#0039A6', C: '#0039A6', E: '#0039A6',
      B: '#FF6319', D: '#FF6319', F: '#FF6319', M: '#FF6319',
      G: '#6CBE45', J: '#996633', Z: '#996633',
      N: '#FCCC0A', Q: '#FCCC0A', R: '#FCCC0A', W: '#FCCC0A',
      L: '#A7A9AC', '1': '#EE352E', '2': '#EE352E', '3': '#EE352E',
      '4': '#00933C', '5': '#00933C', '6': '#00933C',
      '7': '#B933AD', SI: '#00A8B5'
    };

    window.addEventListener('DOMContentLoaded', () => {
      fetchLiveData();
      setupAutoRefresh();
      initLeafletMap();
    });

    function switchTab(tab) {
      ['arrivals', 'map', 'accessibility'].forEach(t => {
        document.getElementById(`view-${t}`).classList.add('hidden');
        document.getElementById(`tab-${t}`).className = 'px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-2 text-slate-400 hover:text-white hover:bg-slate-900';
      });

      document.getElementById(`view-${tab}`).classList.remove('hidden');
      document.getElementById(`tab-${tab}`).className = 'px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-2 bg-indigo-600 text-white';

      if (tab === 'map') {
        setTimeout(() => {
          if (leafletMap) {
            leafletMap.invalidateSize();
            leafletMap.setView([40.7128, -74.0060], 12);
            renderMapMarkers();
          }
        }, 200);
      } else if (tab === 'accessibility') {
        fetchAccessibilityData();
      }
    }

    async function fetchLiveData() {
      const btnSpinner = document.getElementById('fetchSpinner');
      btnSpinner.classList.remove('hidden');
      const startTime = performance.now();

      try {
        const response = await fetch('http://localhost:5000/api/v1/trains/live');
        const latency = Math.round(performance.now() - startTime);

        if (!response.ok) throw new Error(`HTTP Error: ${response.status}`);
        const json = await response.json();
        
        rawApiResponse = json;
        allTrains = json.data || [];

        updateStatus('ONLINE', 'Connected', latency);
        document.getElementById('metricTrainCount').innerText = json.count ?? allTrains.length;
        document.getElementById('metricCacheEngine').innerText = json.cacheBackend || 'Redis';
        document.getElementById('metricLastFetch').innerText = new Date().toLocaleTimeString();
        document.getElementById('metricCacheStatus').innerHTML = json.cache === 'hit' 
          ? `<span class="text-sm font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2.5 py-0.5 rounded">CACHE HIT</span>`
          : `<span class="text-sm font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30 px-2.5 py-0.5 rounded">CACHE MISS</span>`;

        document.getElementById('jsonViewer').innerText = JSON.stringify(json, null, 2);
        renderGrid();
        if (!document.getElementById('view-map').classList.contains('hidden')) renderMapMarkers();

      } catch (err) {
        updateStatus('OFFLINE', 'Backend Offline');
      } finally {
        btnSpinner.classList.add('hidden');
      }
    }

    function updateStatus(status, label, latency = null) {
      const badge = document.getElementById('connectionStatusBadge');
      const dot = document.getElementById('statusDot');
      const text = document.getElementById('statusText');
      const latBadge = document.getElementById('latencyBadge');

      if (status === 'ONLINE') {
        badge.className = 'flex items-center gap-2 px-3 py-1.5 rounded-full border text-xs font-medium bg-emerald-950/80 border-emerald-800 text-emerald-400';
        dot.className = 'w-2.5 h-2.5 rounded-full bg-emerald-400 pulse-dot';
        text.innerText = label;
        if (latency !== null) {
          latBadge.classList.remove('hidden');
          document.getElementById('latencyText').innerText = `${latency} ms`;
        }
      } else {
        badge.className = 'flex items-center gap-2 px-3 py-1.5 rounded-full border text-xs font-medium bg-red-950/80 border-red-800 text-red-400';
        dot.className = 'w-2.5 h-2.5 rounded-full bg-red-500';
        text.innerText = label;
        latBadge.classList.add('hidden');
      }
    }

    function filterByRoute(route) {
      selectedRoute = route;
      document.querySelectorAll('.route-filter-btn').forEach(btn => btn.classList.remove('ring-2', 'ring-indigo-400', 'ring-offset-2', 'ring-offset-slate-950'));
      event.target.classList.add('ring-2', 'ring-indigo-400', 'ring-offset-2', 'ring-offset-slate-950');
      document.getElementById('filterCountBadge').innerText = route === 'ALL' ? 'Showing: All Lines' : `Filter: ${route} Line`;
      renderGrid();
      if (!document.getElementById('view-map').classList.contains('hidden')) renderMapMarkers();
    }

    function handleSearch() {
      searchQuery = document.getElementById('searchInput').value.trim().toLowerCase();
      renderGrid();
    }

    function renderGrid() {
      const container = document.getElementById('trainsGrid');
      container.innerHTML = '';
      const nowEpoch = Math.floor(Date.now() / 1000);

      const filtered = allTrains.filter(train => {
        const matchesRoute = (selectedRoute === 'ALL') || (train.routeId === selectedRoute);
        const matchesSearch = !searchQuery || 
          (train.tripId && train.tripId.toLowerCase().includes(searchQuery)) ||
          (train.stopTimeUpdates && train.stopTimeUpdates.some(s => (s.stopName && s.stopName.toLowerCase().includes(searchQuery))));
        return matchesRoute && matchesSearch;
      });

      filtered.forEach(train => {
        const badgeColor = routeColorMap[train.routeId] || 'bg-slate-700 text-white';
        let stopsHtml = train.stopTimeUpdates ? train.stopTimeUpdates.slice(0, 4).map(stop => {
          const arrivalTime = stop.arrivalTime || stop.departureTime;
          let arrivalMinutes = '--';
          if (arrivalTime) {
            const diffSec = arrivalTime - nowEpoch;
            arrivalMinutes = diffSec <= 30 ? 'Due' : `${Math.floor(diffSec / 60)} min`;
          }
          return `
            <div class="flex items-center justify-between text-xs py-2 border-b border-slate-800/60 last:border-0 gap-2">
              <span class="text-slate-300 font-medium truncate">${stop.stopName || stop.stopId}</span>
              <span class="font-mono px-2 py-0.5 rounded ${arrivalMinutes === 'Due' ? 'bg-amber-500/20 text-amber-400 font-bold' : 'text-indigo-400 bg-indigo-950/60'}">${arrivalMinutes}</span>
            </div>
          `;
        }).join('') : '';

        const card = document.createElement('div');
        card.className = 'bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between';
        card.innerHTML = `
          <div>
            <div class="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
              <div class="flex items-center gap-2.5">
                <span class="w-9 h-9 rounded-full flex items-center justify-center font-extrabold text-sm ${badgeColor}">${train.routeId || '?'}</span>
                <div>
                  <h4 class="text-xs font-semibold text-slate-200">Route ${train.routeId} Train</h4>
                  <p class="text-[10px] text-slate-500 font-mono">ID: ${train.tripId}</p>
                </div>
              </div>
            </div>
            <div class="space-y-0.5">${stopsHtml}</div>
          </div>
        `;
        container.appendChild(card);
      });
    }

    function initLeafletMap() {
      // 1. Initialize Map centered on NYC
      leafletMap = L.map('mapContainer', {
        crs: L.CRS.EPSG3857,
        center: [40.7128, -74.0060],
        zoom: 12
      });

      // 2. Add Standard OpenStreetMap Tile Layer (Reliable Base Map)
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '&copy; OpenStreetMap contributors'
      }).addTo(leafletMap);
      
      trackLinesGroup = L.layerGroup().addTo(leafletMap);
      mapMarkersGroup = L.layerGroup().addTo(leafletMap);

      loadSubwayTrackLines();
    }

    async function loadSubwayTrackLines() {
      try {
        const response = await fetch('http://localhost:5000/api/v1/routes/shapes');
        if (!response.ok) return;
        const geoJsonData = await response.json();

        L.geoJSON(geoJsonData, {
          style: (feature) => {
            const rt = feature.properties ? (feature.properties.rt_symbol || feature.properties.route_id) : null;
            const lineColor = hexColorMap[rt] || '#64748b';
            return {
              color: lineColor,
              weight: 4,
              opacity: 0.9
            };
          },
          filter: (feature) => {
            if (selectedRoute === 'ALL') return true;
            const rt = feature.properties ? (feature.properties.rt_symbol || feature.properties.route_id) : null;
            return rt === selectedRoute;
          },
          onEachFeature: (feature, layer) => {
            const rt = feature.properties ? (feature.properties.rt_symbol || feature.properties.route_id) : '?';
            const badgeColorClass = routeColorMap[rt] || 'bg-slate-700 text-white';

            if (feature.geometry && (feature.geometry.type === 'LineString' || feature.geometry.type === 'MultiLineString')) {
              let coordsArray = feature.geometry.coordinates;
              if (feature.geometry.type === 'MultiLineString') {
                coordsArray = coordsArray[0];
              }

              if (coordsArray && coordsArray.length > 0) {
                // GeoJSON format is [longitude, latitude] -> Invert to [latitude, longitude] for Leaflet
                const startCoord = [coordsArray[0][1], coordsArray[0][0]];
                const endCoord = [coordsArray[coordsArray.length - 1][1], coordsArray[coordsArray.length - 1][0]];

                const terminalIcon = L.divIcon({
                  className: '',
                  html: `<div class="mta-map-bullet ${badgeColorClass}">${rt}</div>`,
                  iconSize: [24, 24],
                  iconAnchor: [12, 12]
                });

                L.marker(startCoord, { icon: terminalIcon }).addTo(trackLinesGroup);
                L.marker(endCoord, { icon: terminalIcon }).addTo(trackLinesGroup);
              }
            }
          }
        }).addTo(trackLinesGroup);
      } catch (e) {
        console.warn('Could not render subway track line overlays:', e);
      }
    }

    function renderMapMarkers() {
      if (!mapMarkersGroup) return;
      mapMarkersGroup.clearLayers();

      if (trackLinesGroup) {
        trackLinesGroup.clearLayers();
        loadSubwayTrackLines();
      }

      const seenStops = new Set();

      allTrains.forEach(train => {
        if (selectedRoute !== 'ALL' && train.routeId !== selectedRoute) return;
        if (!train.stopTimeUpdates) return;

        train.stopTimeUpdates.forEach(stop => {
          if (stop.lat && stop.lon) {
            const stopKey = `${train.routeId}_${stop.stopId}`;
            if (seenStops.has(stopKey)) return;
            seenStops.add(stopKey);

            const lineColor = hexColorMap[train.routeId] || '#ffffff';

            const circleMarker = L.circleMarker([stop.lat, stop.lon], {
              radius: 4.5,
              fillColor: '#ffffff',
              color: lineColor,
              weight: 2,
              opacity: 1,
              fillOpacity: 1
            });

            circleMarker.bindPopup(`
              <div class="p-1 font-sans">
                <div class="font-bold text-slate-900 text-sm">${stop.stopName || stop.stopId}</div>
                <div class="text-xs text-slate-600 font-medium">Route ${train.routeId} Station</div>
                <div class="text-[10px] text-slate-500 font-mono mt-1">Stop ID: ${stop.stopId}</div>
              </div>
            `);

            mapMarkersGroup.addLayer(circleMarker);
          }
        });
      });
    }

    function recenterMap() {
      if (leafletMap) leafletMap.setView([40.7128, -74.0060], 12);
    }

    async function fetchAccessibilityData() {
      const container = document.getElementById('outagesGrid');
      container.innerHTML = '<p class="text-xs text-slate-400">Loading outages...</p>';

      try {
        const res = await fetch('http://localhost:5000/api/v1/accessibility');
        const json = await res.json();
        container.innerHTML = '';

        if (!json.data || json.data.length === 0) {
          container.innerHTML = '<p class="text-xs text-slate-400">No active elevator or escalator outages reported.</p>';
          return;
        }

        json.data.forEach(outage => {
          const card = document.createElement('div');
          card.className = 'bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-2';
          card.innerHTML = `
            <div class="flex items-center justify-between">
              <span class="text-xs font-bold ${outage.equipmentType === 'Elevator' ? 'text-amber-400' : 'text-blue-400'}">${outage.equipmentType} Outage</span>
              <span class="text-[10px] font-mono bg-slate-950 px-2 py-0.5 rounded text-slate-400">${outage.equipmentId}</span>
            </div>
            <h4 class="text-sm font-semibold text-slate-200">${outage.stationName}</h4>
            <p class="text-xs text-slate-400">${outage.reason}</p>
            <p class="text-[10px] text-slate-500">Return to service: ${outage.estimatedReturn}</p>
          `;
          container.appendChild(card);
        });
      } catch (err) {
        container.innerHTML = '<p class="text-xs text-red-400">Failed to load accessibility outage data.</p>';
      }
    }

    function setupAutoRefresh(ms = 15000) {
      if (autoRefreshTimer) clearInterval(autoRefreshTimer);
      if (ms > 0) autoRefreshTimer = setInterval(fetchLiveData, ms);
    }

    function toggleJsonModal(show) {
      document.getElementById('jsonModal').classList.toggle('hidden', !show);
      document.getElementById('jsonModal').classList.toggle('flex', show);
    }
  </script>
</body>
</html>